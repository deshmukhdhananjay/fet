$(document).ready(function() {
    $("button").click(function() {
        var email = $('#email').val();
        var password = $('#pwd').val();

        let record = {
            // "name": $('#ip').val(),
            // "pwd": $('#ip2').val()
            "name": email,
            "pwd": password
        }
        $.ajax({
            url: " http://localhost:3000/users",
            type: "post",
            data: record,
            dataType: 'JSON',
            success: function() {
                $('form').submit();
            },
            error: function() {
                alert("getting error");
            }

        });

    });
});